# mean-angular-chat-app

Step to run:

* Prepare Node.js and Angular CLI
* Clone this repo
* Run 'npm install'
* Run 'ng build --env=prod'
* Run 'nodemon' or 'npm start'
